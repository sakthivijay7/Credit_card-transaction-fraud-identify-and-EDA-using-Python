
-- Tables check
describe patients;   
describe admissions;
describe billings;
describe medicalrecords;
  -- Data insert check
select*from healthcare.patients;
select*from healthcare.admissions;
select*from healthcare.billing;
select*from healthcare.medicalrecords;

